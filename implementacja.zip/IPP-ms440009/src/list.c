/** @file
 * Moduł realizujący podstaowe działania na liście

 * @author Michał Sobczak <ms440009@mimuw.edu.pl>.
 * @copyright Uniwersytet Warszawski
 * @date 2022
 */
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "list.h"
#include "phone_forward.h"
#include "utils.h"

ListNode *listNew(void)
{
    ListNode *list = calloc(1, sizeof(ListNode));
    if (list == NULL)
    {
        return NULL;
    }

    return list;
}

void deleteList(ListNode *list)
{
    while (list != NULL)
    {
        ListNode *temporary = list;
        list = list->next;
        free(temporary->number);
        free(temporary);
    }
}

ListNode *addList(ListNode *list, char *arrayChar)
{
    ListNode *newListNode = listNew();
    newListNode->number = arrayChar;
    newListNode->next = list;
    return newListNode;
}

ListNode *createList(ListNode *answer, ListNode *list, char *num, int index)
{
    while (list != NULL)
    {
        char *newCharArray = createCharArray(list->number, num, index);
        answer = addList(answer, newCharArray);
        list = list->next;
    }
    return answer;
}

char **convertListtoArray(ListNode *numberList, int size)
{
    char **numbers = pointerCharNew(size);
    for (int i = 0; i < size; i++)
    {
        char *number = numberList->number;
        copyPrefix(&numbers[i], number, arrayCharSize(number));
        numberList = numberList->next;
    }
    return numbers;
}