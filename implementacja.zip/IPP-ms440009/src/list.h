/** @file
 * Moduł zawiera podstawowe działania na liście.

 * @author Michał Sobczak <ms440009@mimuw.edu.pl>.
 * @copyright Uniwersytet Warszawski
 * @date 2022
 */
#ifndef __LISTA_H__
#define __LISTA_H__

/**
 * To jest struktura w postaci listy.
 * Zawiera ona informacje o numerach przekierowań.
 */

struct ListNode
{
  char *number;          ///< Wskaźnik na numer zapisany w liście;
  struct ListNode *next; ///< Wskaźnik na kolejny element listy.
};
/**
 * Jest to struktura w postaci listy.
 */
typedef struct ListNode ListNode;

/** @brief Tworzy nową strukturę.
 * Tworzy nową strukturę niezawierającą żadnego elementu.
 * @return Wskaźnik na utworzoną strukturę lub NULL, gdy nie udało się
 *         alokować pamięci.
 */
ListNode *listNew(void);

/** @brief Usuwa strukturę.
 * Usuwa strukturę wskazywaną przez @p list. Nic nie robi, jeśli
 * wskaźnik ten ma wartość NULL.
 * @param[in] list – wskaźnik na usuwaną strukturę.
 */
void deleteList(ListNode *list);

/** @brief Tworzy element listy.
 * Tworzy nowy element listy o numerze równym @p arrayChar.
 * @param[in,out] list – wskaźnik na usuwaną strukturę;
 * @param[in] arrayChar- wskaźnik na napis;
 * @return Wskaźnik na nowy element listy.
 */
ListNode *addList(ListNode *list, char *arrayChar);

/** @brief Tworzy listę.
 * Tworzy listę wskazywaną przez @p answer. Składa się ona z elementów
 * zawierających szukane numery. Numery te składają się z prefiksu zawartego w
 * @p list oraz sufiksu zapisanego od pozycji @p index w napisie
 * wskazywanym przez @p num.
 * @param[in, out] answer - wskaźnik na listę, do której dodawane są nowe elementy;
 * @param[in] list        - wskaźnik na listę, która przechowuje prefiks słowa;
 * @param[in] num         - wskaźnik na napis, z którego zostanie skopiowany
 *                          sufiks;
 * @param[in] index       - numer miejsca w tablicy od którego zostanie przepisany
 *                          sufiks.
 *
 * @return Wskaźnik na listę, która została utworzona.
 */
ListNode *createList(ListNode *answer, ListNode *list, char *num, int index);

/**
 * @brief Kopiuje numery.
 * Tworzy tablicę o rozmiarze @p size i przepisuje do niej numery zapisane w
 * @p numberList.
 * @param[in] numberList- wskaźnik na listę, z której zostaną pobrane numery;
 * @param[in] size      - rozmiar tablicy, która zostanie utworzona;
 * @return  Wskaźnik na tablicę, która zawiera numery.
 */
char **convertListtoArray(ListNode *numberList, int size);

#endif /*__LIST_H__*/