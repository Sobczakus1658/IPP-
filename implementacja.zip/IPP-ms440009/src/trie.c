#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "list.h"
#include "trie.h"
#include "phone_forward.h"
#include "utils.h"

NumberTrie *trieNew(void)
{
    NumberTrie *trie = calloc(1, sizeof(NumberTrie));
    if (trie == NULL)
    {
        return NULL;
    }

    return trie;
}

void deleteTrie(NumberTrie *trie)
{
    while (trie != NULL)
    {
        int candidate = MAX_CHILDREN;

        for (int i = 0; i < MAX_CHILDREN; i++)
        {
            if (trie->children[i] != NULL)
            {
                candidate = i;
            }
        }
        if (candidate < MAX_CHILDREN)
        {
            trie = trie->children[candidate];
            trie->parent->children[candidate] = NULL;
        }
        else
        {
            NumberTrie *parent = trie->parent;
            phnumDelete(trie->prefiks);
            deleteList(trie->reverseList);
            free(trie);
            trie = parent;
        }
    }
}

NumberTrie *findVertex(PhoneForward *pf, NumberTrie *vertex, char const *num)
{
    size_t temporarySize = 0;
    size_t size = arrayCharSize(num);
    int value;

    while (temporarySize < size)
    {
        value = convertToNumber(num[temporarySize]);

        if (vertex->children[value] == NULL)
        {
            NumberTrie *newNumberTrie = trieNew();
            if (newNumberTrie == NULL)
            {
                phfwdDelete(pf);
                return 0;
            }

            newNumberTrie->parent = vertex;
            vertex->children[value] = newNumberTrie;
        }

        vertex = vertex->children[value];
        temporarySize++;
    }
    return vertex;
}

bool dataValidation(PhoneForward *root, char const *num)
{
    if (num != NULL && root != 0)
    {
        size_t size = arrayCharSize(num);

        if (size == 0)
        {
            return 0;
        }

        return 1;
    }
    return 0;
}
