/** @file
 * Program realizujący przekierowania numerów telefonicznych.

 * @author Michał Sobczak <ms440009@mimuw.edu.pl>.
 * @copyright Uniwersytet Warszawski
 * @date 2022
 */
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "phone_forward.h"
#include "list.h"
#include "trie.h"
#include "utils.h"

PhoneForward *phfwdNew(void)
{
    PhoneForward *numer = calloc(1, sizeof(PhoneForward));
    numer->forwards = trieNew();
    numer->reverse = trieNew();
    if (numer == NULL)
    {
        return NULL;
    }

    return numer;
}

PhoneNumbers *phnumNew(void)
{
    PhoneNumbers *number = calloc(1, sizeof(PhoneNumbers));
    if (number == NULL)
    {
        return NULL;
    }

    return number;
}

void phnumDelete(PhoneNumbers *pnum)
{
    if (pnum != NULL)
    {
        for (size_t i = 0; i < pnum->memoryAllocatedSize; i++)
        {
            free(pnum->phoneNumber[i]);
        }

        free(pnum->phoneNumber);
        free(pnum);
    }
}

void phfwdDelete(PhoneForward *pf)
{
    if (pf != NULL)
    {
        deleteTrie(pf->forwards);
        deleteTrie(pf->reverse);
        free(pf);
    }
}

/**
 * @brief Usuwa z listy.
 * Usuwa z listy przekierowań wierzchołka @p root element o wskaźniku @p element.
 * @param[in] root         - wskaźnik na wierzchołek drzewa, który zawiera listę
 *                           zawierającą @p element;
 * @param[in, out] element - element, który zostanie usunięty.
 */
void removeFromList(NumberTrie *root, ListNode *element)
{
    if (root == NULL)
    {
        return;
    }

    if (root->reverseList == element)
    {
        root->reverseList = element->next;
        free(element->number);
        free(element);
    }
    else
    {
        ListNode *previous = root->reverseList;
        while (previous->next != element)
        {
            previous = previous->next;
        }

        if (element->next != NULL)
        {
            previous->next = element->next;
        }
        else
        {
            previous->next = NULL;
        }

        free(element->number);
        free(element);
    }
}

/**
 * @brief Usuwa przekierowanie.
 * Usuwa przekierowanie z drzewa wskazywanego przez @p vertex.
 * @param[in] vertex - wierzchołek drzewa.
 */
void deleteForwardFromReverse(NumberTrie *vertex)
{
    if (vertex != NULL)
    {
        for (int i = 0; i < MAX_CHILDREN; i++)
        {
            deleteForwardFromReverse(vertex->children[i]);
        }
        removeFromList(vertex->reverseTree, vertex->reverseListNode);
    }
}

/** @brief Usuwa poddrzewo.
 * Usuwa strukturę wskazywaną przez @p root. W przypadku gdy chcemy usunąć dane
 * poddrzewo, sprawdzam, czy mogę zwolnić więcej pamięci. Będzie to możliwe jeżeli
 * jego ojciec nie ma innych dzieci oraz nie ma żadnego przekierowania. W takim
 * przypadku usunę wierzchołek, który jest dzieckiem numer @p toDelete swojego ojca.
 * Jeżeli nie da się usunąc więcej, usuwam korzeń ktory jest dzieckiem numer
 * @p lastChild swojego ojca.
 * @param[in,out] root   – wskaźnik na usuwaną strukturę;
 * @param[in] lastChild  – numer dziecka swojego ojca;
 * @param[in] toDelete   – numer dziecka swojego ojca gdy da się usunąć większą
 *                         część drzewa.
 */
void delete (NumberTrie *root, int lastChild, int toDelete)
{
    if (toDelete < MAX_CHILDREN)
    {
        lastChild = toDelete;
        NumberTrie *child = root->children[lastChild];
        root->children[lastChild] = NULL;
        child->parent = NULL;
        deleteForwardFromReverse(child);
        deleteTrie(child);
    }
    else
    {
        root->parent->children[lastChild] = NULL;
        root->parent = NULL;
        deleteForwardFromReverse(root);
        deleteTrie(root);
    }
}

/** @brief Ustawia przekierowanie.
 * Ustawia przekierowanie o wartości @p num do wierzchołka @p trie.
 * @param[in,out] trie – wskaźnik na drzewo, do którego zostanie dodane
 *                       przekierowanie;
 * @param[in] num      – wartość przekierowania.
 */
static void setForward(NumberTrie *trie, char const *num)
{
    size_t size = arrayCharSize(num);
    char *arrayChar = charNew(size);
    for (size_t i = 0; i < size; i++)
    {
        arrayChar[i] = num[i];
    }

    removeFromList(trie->reverseTree, trie->reverseListNode);

    phnumDelete(trie->prefiks);
    trie->prefiks = phnumNew();
    trie->prefiks->arraySize = size;
    trie->prefiks->memoryAllocatedSize = 1;
    trie->prefiks->phoneNumber = pointerCharNew(1);
    trie->prefiks->phoneNumber[0] = arrayChar;
}

/** @brief Ustawia przekierowanie w liście.
 * Ustawia przekierowanie o wartości @p num do wierzchołka @p trie.
 * Wierzchołek @p v z odwróconeego drzewa zapamiętuje wskaźnik na
 * nowe przekierowanie.
 * @param[in,out] v    - wskaźnik na równoległe drzewo;
 * @param[in,out] trie – wskaźnik na drzewo, do którego zostanie dodane
 *                       przekierowanie;
 * @param[in] num      – wartość przekierowania.
 */
static void setForwardList(NumberTrie *v, NumberTrie *trie, char const *num)
{
    size_t size = arrayCharSize(num);
    char *arrayChar = charNew(size + 1);
    for (size_t i = 0; i < size; i++)
    {
        arrayChar[i] = num[i];
    }
    ListNode *pointer = addList(trie->reverseList, arrayChar);
    trie->reverseList = pointer;
    v->reverseListNode = pointer;
}

bool phfwdAdd(PhoneForward *pf, char const *num1, char const *num2)
{
    if (arrayCharSize(num1) == 0 || arrayCharSize(num2) == 0 || pf == NULL)
    {
        return 0;
    }

    if (isSameArrayChar(num1, num2))
    {
        return 0;
    }
    NumberTrie *vertex = pf->forwards;

    vertex = findVertex(pf, vertex, num1);
    setForward(vertex, num2);
    NumberTrie *forwardVertex = vertex;

    vertex = pf->reverse;
    vertex = findVertex(pf, vertex, num2);

    setForwardList(forwardVertex, vertex, num1);
    forwardVertex->reverseTree = vertex;

    return 1;
}

void phfwdRemove(PhoneForward *pf, char const *num)
{
    if (!dataValidation(pf, num))
    {
        return;
    }
    NumberTrie *vertex = pf->forwards;
    size_t temporarySize = 0;
    size_t size = arrayCharSize(num);
    size_t lastChild = convertToNumber(num[size - 1]);
    int value;

    while (temporarySize < size)
    {
        value = convertToNumber(num[temporarySize]);
        if (vertex->children[value] == NULL)
        {
            return;
        }
        else
        {
            vertex = vertex->children[value];
            temporarySize++;
        }
    }

    int toDelete = MAX_CHILDREN;
    while (vertex->parent != NULL && vertex->parent->prefiks == NULL)
    {
        int childrenCount = 0;
        int candidate = MAX_CHILDREN;

        for (int i = 0; i < MAX_CHILDREN; i++)
        {
            if (vertex->parent->children[i] != NULL)
            {
                childrenCount++;
                candidate = i;
            }
        }

        if (childrenCount == 1)
        {
            toDelete = candidate;
            vertex = vertex->parent;
        }
        else
        {
            break;
        }
    }

    delete (vertex, lastChild, toDelete);
}

/** @brief Dodaje cyfrę do napisu.
 * Do napisu wskazywanego przez @p pointerArray dopisuje liczbę równą wartości
 * @p number. Zwiększamy @p size o 1, a w przypadku braku miejsca w tablicy,
 * zwiększa jej rozmiar @p aSize. W przypadku nieudanej alokacji pamięci,
 * przerywa program.
 * @param[in,out] pointerArray – wskaźnik na napis, do którego dopisujemy cyfrę;
 * @param[in] number           – cyfra którą chcemy dopisać;
 * @param[in,out] size         – aktualna długość napisu;
 * @param[in,out] aSize        - rozmiar tablicy znaków reprezentowany przez
 *                               @p pointerArray.
 */
static void addDigit(char **pointerArray, int number, int *size, int *aSize)
{
    if (*size >= *aSize)
    {
        *aSize = (*aSize) * 2 + 2;
        (*pointerArray) = realloc((*pointerArray), *aSize * sizeof(char));

        if ((*pointerArray) == NULL)
        {
            return;
        }
    }

    (*pointerArray)[*size] = (char)(number + '0');
    if (number == 10)
    {
        (*pointerArray)[*size] = '*';
    }
    if (number == 11)
    {
        (*pointerArray)[*size] = '#';
    }
    (*size)++;
}

/** @brief Kończy słowo.
 * Dopisuje na koniec @p pointerArray znak informujący o końcu napisu.
 * Jeżeli długość słowa @p size nie mieści się w tablicy o długośći @p aSize,
 * to najpierw zwiększamy rozmiar tablicy @p aSize. W przypadku nieudanej
 * alokacji pamięci przerywa program.
 * @param[in,out] pointerArray – wskaźnik na napis, do którego zostanie dopisany
 *                               znak informujący o końcu napisu;
 * @param[in,out] size         – aktualna długość słowa;
 * @param[in,out] aSize        – rozmiar tablicy znaków reprezentowany przez
 *                               @p pointerArray.
 */
static void addEndOfChar(char **pointerArray, int *size, int *aSize)
{
    if (*size >= *aSize)
    {
        *aSize = (*aSize) + 2;
        *pointerArray = realloc(*pointerArray, *aSize * sizeof(char));

        if ((*pointerArray) == NULL)
        {
            return;
        }
    }

    (*pointerArray)[*size] = '\0';
    (*size)++;
}

/** @brief Wyznacza przekierowanie numeru.
 * Wyznacza przekierowanie podanego numeru i zapisuje je pod @p phnum. Szuka
 * najdłuższego pasującego prefiksu do @p num w strukturze @p pf. Wynikiem jest
 * ciąg zawierający co najwyżej jeden numer. Jeśli dany numer nie został
 * przekierowany, to wynikiem jest ciąg zawierający ten numer.
 * @param[in,out] phnum – wskaźnik na strukturę przechowującą ciąg numerów
 *                        telefonów, zapisuje na niej utworzone przekierowanie;
 * @param[in] trie      – wskaźnik na strukturę przechowującą przekierowania
 *                        numerów;
 * @param[in] num       – wskaźnik na napis reprezentujący numer.
 * @return Przekierowanie numeru, w przypadku błędu zwraca NULL
 */
static PhoneNumbers *create(PhoneNumbers *phnum, NumberTrie const *trie, char const *num)
{
    size_t size = arrayCharSize(num);
    size_t temporarySize = 0;
    int value = convertToNumber(num[temporarySize]);
    char *arrayChar = charNew(1);
    int arraySize = 0;
    int memoryAllocatedSize = 1;

    while (temporarySize < size && trie->children[value] != NULL)
    {
        if (trie->children[value]->prefiks != NULL)
        {
            free(arrayChar);
            arraySize = 0;
            arraySize = trie->children[value]->prefiks->arraySize;
            char *toCopy = trie->children[value]->prefiks->phoneNumber[0];
            copyPrefix(&arrayChar, toCopy, arraySize);
            memoryAllocatedSize = arraySize;
        }
        else
        {
            addDigit(&arrayChar, value, &arraySize, &memoryAllocatedSize);
        }

        trie = trie->children[value];
        temporarySize++;
        value = convertToNumber(num[temporarySize]);

        if (temporarySize < size && (value > 11 || value < 0))
        {
            phnumDelete(phnum);
            phnum = phnumNew();

            if (phnum == NULL)
            {
                return NULL;
            }

            return phnum;
        }
    }

    while (temporarySize < size)
    {
        value = convertToNumber(num[temporarySize]);
        addDigit(&arrayChar, value, &arraySize, &memoryAllocatedSize);
        temporarySize++;
    }

    addEndOfChar(&arrayChar, &arraySize, &memoryAllocatedSize);
    phnum->phoneNumber = pointerCharNew(1);
    phnum->phoneNumber[0] = arrayChar;
    phnum->arraySize = temporarySize;
    phnum->memoryAllocatedSize = 1;
    return phnum;
}

PhoneNumbers *phfwdGet(PhoneForward const *pf, char const *num)
{
    if (pf == NULL)
    {
        return NULL;
    }
    PhoneNumbers *number;
    number = phnumNew();

    if (number == NULL)
    {
        return NULL;
    }

    if (num == NULL)
    {
        return number;
    }

    size_t size = arrayCharSize(num);
    if (size <= 0)
    {
        return number;
    }

    return create(number, pf->forwards, num);
}

char const *phnumGet(PhoneNumbers const *pnum, size_t idx)
{

    if (pnum == NULL || pnum->memoryAllocatedSize <= idx)
    {
        return NULL;
    }
    else
    {
        return pnum->phoneNumber[idx];
    }
}

/**
 * @brief Sortuje dane.
 * Sortuje tablicę napisów @p array o długości @p size.
 * @param array - wskaźnik na napisy, które zostana uporządkowane;
 * @param size  - rozmiar sortowanej tablicy.
 */
void sort(char **array, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size - 1; j++)
        {
            if (bigger(array[j], array[j + 1]) == -1)
            {
                char *temporary = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temporary;
            }
        }
    }
}

/**
 * @brief Tworzy listę numerów.
 * Tworzy listę numerów, które zostały przekierowane na @p num i są
 * zapisane w @p vertex.
 * @param vertex - wierzchołek drzewa, gdzie zapisane są przekierowania;
 * @param num    - wskaźnik na numer, na który szukamy przekierowań;
 * @return Wskaźnik na listę zawierającą numery przekierowane na @p num.
 */
ListNode *reverseNumbers(NumberTrie const *vertex, char const *num)
{
    char *copy = charNew(arrayCharSize(num) + 1);
    for (size_t i = 0; i < arrayCharSize(num); i++)
    {
        copy[i] = num[i];
    }

    ListNode *numberList = NULL;
    int value;
    for (size_t i = 0; i < arrayCharSize(num); i++)
    {
        value = convertToNumber(num[i]);
        if (vertex->children[value] == NULL)
        {
            break;
        }
        if (vertex->children[value] != NULL)
        {
            ListNode *list = vertex->children[value]->reverseList;
            numberList = createList(numberList, list, copy, i + 1);
            vertex = vertex->children[value];
        }
    }
    numberList = addList(numberList, copy);
    return numberList;
}

PhoneNumbers *phfwdReverse(PhoneForward const *pf, char const *num)
{
    if (pf == NULL)
    {
        return NULL;
    }
    PhoneNumbers *pnum;
    pnum = phnumNew();
    size_t charArraySize = arrayCharSize(num);
    if (charArraySize == 0)
    {
        return pnum;
    }

    NumberTrie *vertex = pf->reverse;
    ListNode *numberList = reverseNumbers(vertex, num);

    int size = 0;
    ListNode *listBeginning = numberList;
    while (numberList != NULL)
    {
        size++;
        numberList = numberList->next;
    }
    numberList = listBeginning;
    char **numbers = convertListtoArray(numberList, size);
    deleteList(listBeginning);
    sort(numbers, size);
    numbers = removeDuplicates(numbers, &size);

    pnum->phoneNumber = numbers;
    pnum->memoryAllocatedSize = size;
    return pnum;
}
/**
 * @brief Kopiuje tablicę.
 * Przepisuje wartości wskazywane przez @p copy do @p array.
 *
 * @param array - wskaźnik na napis, do którego zostanie zapisana kopia.
 * @param copy  - wskaźnik na napis, który zostanie skopiowany.
 */
static void copy(char *array, char *copy)
{
    size_t size = arrayCharSize(copy);
    for (size_t i = 0; i < size; i++)
    {
        array[i] = copy[i];
    }
}

PhoneNumbers *phfwdGetReverse(PhoneForward const *pf, char const *num)
{
    if (pf == NULL)
    {
        return NULL;
    }

    PhoneNumbers *pnum = phfwdReverse(pf, num);
    size_t finallySize = 0;

    for (size_t i = 0; i < pnum->memoryAllocatedSize; i++)
    {
        char const *candidate = phnumGet(pnum, i);
        PhoneNumbers *temporary = phfwdGet(pf, candidate);
        char const *array = phnumGet(temporary, 0);

        if (isSameArrayChar(array, num))
        {
            finallySize++;
        }

        phnumDelete(temporary);
    }

    PhoneNumbers *answer = phnumNew();
    char **numbers = pointerCharNew(finallySize);
    size_t j = 0;

    for (size_t i = 0; i < pnum->memoryAllocatedSize; i++)
    {
        char const *candidate = phnumGet(pnum, i);
        PhoneNumbers *temporary = phfwdGet(pf, candidate);
        char const *array = phnumGet(temporary, 0);
        if (isSameArrayChar(array, num))
        {
            numbers[j] = charNew(arrayCharSize(pnum->phoneNumber[i]) + 1);
            copy(numbers[j], pnum->phoneNumber[i]);
            j++;
        }
        phnumDelete(temporary);
    }

    phnumDelete(pnum);
    answer->phoneNumber = numbers;
    answer->memoryAllocatedSize = finallySize;
    return answer;
}
