/** @file
 * Moduł zawierający pomocnicze funkcje.

 * @author Michał Sobczak <ms440009@mimuw.edu.pl>.
 * @copyright Uniwersytet Warszawski
 * @date 2022
 */
#ifndef __UTILS_H__
#define __UTILS_H__

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

/**
 * @brief Sprawdza znak.
 * Sprawdza czy @p a jest hashtagiem (#) lub asteriskiem (*).
 * @param[in] a - podany znak;
 * @return Wartośc @p true w przypadku gdy @p a jest hashtagiem lub asteriskiem.
 *         W przeciwnym przypadku @p false.
 */
bool isHashOrAsterisk(char a);

/**
 * @brief Sprawdza czy znak jest cyfrą.
 * Sprawdza czy @p a jest cyfrą.
 * @param[in] a - podany znak;
 * @return Wartość @p true w przypadku gdy @p a jest cyfrą,
 *         w przeciwnym przypadku @p false.
 */
bool isNumber(char a);

/**
 * @brief Sprawdza poprawność danych.
 * Sprawdza czy @p x jest cyfrą albo hashtagiem albo asteriskiem.
 * @param[in] x - podany znak;
 * @return Wartość @p true w przypadku gdy @p x jest cyfrą albo hashtagiem albo
 *         asteriskiem. W przeciwnym przypadku zwraca @p false.
 */
bool isDigit(char x);

/**
 * @brief Zamiena znak na wartość.
 * Zamienia @p sign na wartość liczbową. Gdy @p sign jest cyfrą to przypisuje
 * mu jej wartość. W przypadku gdy @p sign jest hashtagiem - przypisuje
 * wartość 11, natomiast gdy @p sign jest asteriskiem to przypisuje mu wartość 10.
 * @param[in] sign - podany znak;
 * @return wartość znaku.
 */
int convertToNumber(char sign);

/**
 * @brief Tworzy nową tablicę.
 * Tworzy tablicę, która składa się z prefiksu zapisanego w @p toCopy oraz
 * sufiksu zapisanego w tablicy @p num. Przepisuje tablicę @p num
 * od numeru tablicy równego @p index.
 * @param[in] toCopy- wskaźnik na napis, który zostanie przepisany w całości;
 * @param[in] num   - wskaźnik na napis, który zostanie skopiowany jako sufiks;
 * @param[in] index - numer, który informuje od którego miejsca w tablicy
 *                    zostanie pobrany sufiks.
 * @return Wskaźnik na powstały napis.
 */
char *createCharArray(char *toCopy, char *num, int index);

/** @brief Znajduje długość słowa.
 * Znajduje długość słowa @p num, jeżeli jest poprawnym napisem.
 * @param[in] num – wskaźnik na napis, którego chcemy odczytać długość;
 * @return Długość danego napisu, jeżeli jest poprawny.
 *         Wartość 0 w przypadku, gdy słowo jest puste lub jest NULL-em lub
 *         jeżeli napis jest niepoprawnie zapisany, to znaczy
 *         składa się z elementów, które nie są cyframi lub hashtagiem lub
 *         asteriskiem.
 */
size_t arrayCharSize(char const *num);

/** @brief Przepisuje prefiks.
 * Alokuje nową tablicę @p pointerArrayChar o rozmiarze @p size.
 * Następnie przepisuje @p prefiks do niej.
 * @param[in,out] pointerArrayChar – wskaźnik na strukturę, gdzie zostanie
 *                                   przepisana wartość;
 * @param[in] prefiks              - wskaźnik na strukturę, którą chcemy
 *                                   przepisać;
 * @param[in] size                 - rozmiar tablicy.
 */
void copyPrefix(char **pointerArrayChar, char *prefiks, int size);

/** @brief Tworzy nową strukturę.
 * Tworzy nową pustą strukturę składającą się z @p size alokowanych miejsc.
 * @param[in] size - rozmiar alokowanej pamięci;
 * @return Wskaźnik na utworzoną strukturę lub NULL, gdy nie udało się
 *         alokować pamięci.
 */
char *charNew(size_t size);

/** @brief Tworzy nową strukturę.
 * Tworzy nową pustą strukturę, składającą się z @p size alokowanych miejsc.
 * @param[in] size - rozmiar alokowanej pamięci;
 * @return Wskaźnik na utworzoną strukturę lub NULL, gdy nie udało się
 *         alokować pamięci.
 */
char **pointerCharNew(size_t size);

/**
 * @brief Porównuje liczby.
 * Porównuje liczbę @p a z liczbą @p b.
 * @param[in] a - pierwsza porównywana liczba;
 * @param[in] b - druga porównywana liczba;
 * @return Wartość równą @p a jeżeli liczba a jest mniejsza od @p b,
 *         w przeciwnym przypadku - @p b.
 */
int minn(int a, int b);

/**
 * @brief Ustala porządek leksykograficzny.
 * Sprawdza czy słowo @p num1 jest przed @p num2 w porządku leksykograficznym.
 * @param num1 - wskaźnik na pierwszy porównywany napis;
 * @param num2 - wskaźnik na drugi porównywany napis;
 * @return Wartość 1 jeżeli @p num1 jest przed @p num2,
 *         wartość 2 w przeciwnym przypadku.
 */
int bigger(char *num1, char *num2);

/** @brief Porównuje napisy.
 * Porównuje czy podane napisy @p num1 oraz @p num2 są takie same.
 * @param[in] num1 – wskaźnik na pierwszy napis;
 * @param[in] num2 – wskaźnik na drugi napis;
 * @return Wartość 0 w przypadku, gdy podane słowa się różnią,
 *         wartość 1 kiedy napisy są identyczne.
 */
bool isSameArrayChar(char const *num1, char const *num2);

/**
 * @brief Usuwa powtórzenia.
 * Usuwa z tablicy @p array numery o tej samej wartości. Rozmiar tej tablicy
 * wynosi @p size.
 * @param[in,out] array - wskaźnik na tablicę napisów, gdzie szukane są
 *                        powtórzenia;
 * @param[in] size      - rozmiar podanej tablicy;
 * @return Wskaźnik na tablicę, która nie zawiera powtórzeń.
 */
char **removeDuplicates(char **array, int *size);

/**
 * @brief Porównuje napisy.
 * Porównuje czy podane napisy @p num1 oraz @p num2 są różne.
 * Funkcja ta różni się od isSameArrayChar() przyjmowanymi argumentami.
 * @param[in] num1 - wskaźnik na pierwszy napis;
 * @param[in] num2 - wskaźnik na drugi napis;
 * @return Wartość @p true w przypadku gdy podane napisy są różne,
 *         @p false w przeciwnym przypadku.
 */
bool isDifferent(char *num1, char *num2);

#endif /*__UTILS_H__*/