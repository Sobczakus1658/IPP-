
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#include "utils.h"

bool isHashOrAsterisk(char a)
{
    if (a == '*' || a == '#')
    {
        return 1;
    }

    return 0;
}

bool isNumber(char a)
{
    if (a >= '0' && a <= '9')
    {
        return 1;
    }

    return 0;
}

bool isDigit(char x)
{
    if (isNumber(x) || isHashOrAsterisk(x))
    {
        return 1;
    }

    return 0;
}

char *charNew(size_t size)
{
    char *charArray = calloc(size, sizeof(char));
    if (charArray == NULL)
    {
        return NULL;
    }

    return charArray;
}

int convertToNumber(char sign)
{
    int value = sign - '0';
    if (sign == '#')
    {
        value = 11;
    }
    if (sign == '*')
    {
        value = 10;
    }

    return value;
}

char **pointerCharNew(size_t size)
{
    char **pointerCharArray = calloc(size, sizeof(char *));
    if (pointerCharArray == NULL)
    {
        return NULL;
    }

    return pointerCharArray;
}

void copyPrefix(char **pointerArrayChar, char *prefiks, int size)
{
    *pointerArrayChar = charNew(size + 1);
    for (int i = 0; i < size; i++)
    {
        (*pointerArrayChar)[i] = prefiks[i];
    }
}

char *createCharArray(char *toCopy, char *num, int index)
{
    int size = arrayCharSize(toCopy) + arrayCharSize(num) - index + 1;
    char *newCharArray = charNew(size);
    size_t sizeToCopy = arrayCharSize(toCopy);
    for (size_t i = 0; i <= sizeToCopy; i++)
    {
        newCharArray[i] = toCopy[i];
    }
    size_t sizeNum = arrayCharSize(num);
    for (size_t i = index; i < sizeNum; i++)
    {
        newCharArray[sizeToCopy] = num[i];
        sizeToCopy++;
    }
    return newCharArray;
}

size_t arrayCharSize(char const *num)
{
    if (num == NULL)
    {
        return 0;
    }

    size_t i = 0;

    while (isDigit(num[i]) != 0)
    {
        i++;
    }
    if (num[i] == '\0')
    {
        return i;
    }
    else
    {
        return 0;
    }
}

int minn(int a, int b)
{
    if (a < b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

int bigger(char *num1, char *num2)
{
    for (int i = 0; i < minn(arrayCharSize(num1), arrayCharSize(num2)); i++)
    {
        if (isNumber(num1[i]) && isNumber(num2[i]))
        {
            if (num1[i] > num2[i])
            {
                return -1;
            }
            if (num1[i] < num2[i])
            {
                return 1;
            }
        }
        if (isNumber(num1[i]) && isHashOrAsterisk(num2[i]))
        {
            return 1;
        }
        if (isHashOrAsterisk(num1[i]) && isNumber(num2[i]))
        {
            return -1;
        }
        if (num1[i] == '#' && num2[i] == '*')
        {
            return -1;
        }
        if (num1[i] == '*' && num2[i] == '#')
        {
            return 1;
        }
    }

    if (arrayCharSize(num1) < arrayCharSize(num2))
    {
        return 1;
    }
    return -1;
}

bool isSameArrayChar(char const *num1, char const *num2)
{

    if (arrayCharSize(num1) == arrayCharSize(num2))
    {
        for (size_t i = 0; i < arrayCharSize(num1); i++)
        {
            if (num1[i] != num2[i])
            {
                return 0;
            }
        }
        return 1;
    }

    return 0;
}

char **removeDuplicates(char **array, int *size)
{
    int finalSize = 0;
    for (int i = 0; i < *size; i++)
    {
        if (i != *size - 1 && !isDifferent(array[i], array[i + 1]))
        {
            continue;
        }
        finalSize++;
    }

    int j = 0;
    char **answer = pointerCharNew(finalSize);
    for (int i = 0; i < *size; i++)
    {
        if (i != *size - 1 && !isDifferent(array[i], array[i + 1]))
        {
            free(array[i]);
            continue;
        }
        answer[j] = array[i];
        j++;
    }

    free(array);
    *size = finalSize;
    return answer;
}

bool isDifferent(char *num1, char *num2)
{
    if (arrayCharSize(num1) == arrayCharSize(num2))
    {
        for (size_t i = 0; i < arrayCharSize(num1); i++)
        {
            if (num1[i] != num2[i])
            {
                return true;
            }
        }
        return false;
    }
    return true;
}