/** @file
 * Moduł zawiera podstawowe działania na drzewie.

 * @author Michał Sobczak <ms440009@mimuw.edu.pl>
 * @copyright Uniwersytet Warszawski
 * @date 2022
 */
#ifndef __TRIE_H__
#define __TRIE_H__

#include "phone_forward.h"
#include "list.h"

/**
 * To jest struktura przechowująca ciąg numerów telefonów.
 * Jest w postaci drzewa, dlatego używam sformułowań
 * "ojciec" oraz "dzieci". Wprowadzam pojęcie "odwrócone drzewo".
 * Jest to drzewo przechowujące informację, które przekierowania
 * przechodzą na dany numer. Numery te zapisane są na liście.
 */
struct NumberTrie
{
    struct NumberTrie *parent;                 ///< Wskaźnik na ojca danego wierzchołka;
    PhoneNumbers *prefiks;                     ///< Wskaźnik na przekierowanie;
    struct NumberTrie *children[MAX_CHILDREN]; ///< Wskaźniki na dzieci danego wierzchołka;
    struct ListNode *reverseList;              ///< Wskaźnik na listę w odwróconym drzewie;
    struct NumberTrie *reverseTree;            ///< Wskaźnik na wierzchołek w odwróconym drzewie;
    struct ListNode *reverseListNode;          ///< Wskaźnik na element listy.
};
/**
 * To jest struktura przechowująca ciąg numerów telefonów.
 */
typedef struct NumberTrie NumberTrie;

/** @brief Tworzy nową strukturę.
 * Tworzy nową pustą strukturę.
 * @return Wskaźnik na utworzoną strukturę lub NULL, gdy nie udało się
 *         alokować pamięci.
 */
NumberTrie *trieNew(void);

/** @brief Usuwa strukturę.
 * Usuwa strukturę wskazywaną przez @p trie. Nic nie robi, jeśli
 * wskaźnik ten ma wartość NULL.
 * @param[in, out] trie – wskaźnik na usuwaną strukturę.
 */
void deleteTrie(NumberTrie *trie);

/** @brief Znajduje wierzchołek w drzewie.
 * Przechodzi przez wierzchołki drzewa, wskazywanego przez @p vertex, które
 * są równe kolejnym znakom napisu zapisanego w @p num. W przypadku gdy
 * wierzchołek nie istnieje, tworzy nowy. Gdy alokacja pamięci nie uda się,
 * usuwa elementy z @p pf.
 * @param[in,out] pf         – wskaźnik na strukturę przechowującą przekierowania
 *                             numerów. Struktura ta zawiera wskaźniki na drzewa;
 * @param[in, out] vertex    – wskaźnik na drzewo przechowujące przekierowania;
 * @param[in] num            – wskaźnik na napis, którego szukamy w drzewie.
 *
 * @return Zwraca wskaźnik na wierzchołek drzewa, do którego zostanie dodane
 *         przekierowanie.
 */
NumberTrie *findVertex(PhoneForward *pf, NumberTrie *vertex, char const *num);

/** @brief Bada poprawność danych.
 * Bada czy podane dane są poprawne, czy @p root nie jest NULL-em oraz czy
 * @p num jest poprawnie podanym napisem, to znaczy składa się tylko z cyfr
 * albo hashtagu albo asterisku.
 * @param[in] root – wskaźnik na wierzchołek drzewa;
 * @param[in] num  – wskaźnik na napis.
 * @return Wartość 0 w przypadku, gdy dane są niepoprawne,
 *         wartość 1 w przeciwnym przypadku.
 */
bool dataValidation(PhoneForward *root, char const *num);

#endif /*__TRIE_H__*/