var searchData=
[
  ['memoryallocatedsize_126',['memoryAllocatedSize',['../structPhoneNumbers.html#a5e0e6a6a56f94ed6e254349c4e3105ce',1,'PhoneNumbers']]]
];
