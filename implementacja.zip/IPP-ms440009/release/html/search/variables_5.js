var searchData=
[
  ['parent_129',['parent',['../structNumberTrie.html#a5ecfdf14ddb9fead8dce29a9c4c9a1aa',1,'NumberTrie']]],
  ['phonenumber_130',['phoneNumber',['../structPhoneNumbers.html#a38f09df37733e456bbe6be038447530e',1,'PhoneNumbers']]],
  ['prefiks_131',['prefiks',['../structNumberTrie.html#a6431fdfa25e7b3c910129b819318a975',1,'NumberTrie']]]
];
