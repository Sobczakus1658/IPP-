var searchData=
[
  ['numbertrie_137',['NumberTrie',['../trie_8h.html#a69db5ef17a97f0bc9fdf67df725728c3',1,'trie.h']]]
];
