var searchData=
[
  ['trie_2eh_77',['trie.h',['../trie_8h.html',1,'']]]
];
