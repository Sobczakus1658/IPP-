var searchData=
[
  ['removeduplicates_56',['removeDuplicates',['../utils_8h.html#aa2f3dd152ff0bde4f8ce75dd4d3369e9',1,'utils.c']]],
  ['removefromlist_57',['removeFromList',['../phone__forward_8c.html#a5487ba07291365bb9d4cff6ceb0f8e6d',1,'phone_forward.c']]],
  ['reverse_58',['reverse',['../structPhoneForward.html#a39d6c991760bef09ea7eea329515ff6b',1,'PhoneForward']]],
  ['reverselist_59',['reverseList',['../structNumberTrie.html#a3138af2bfb114275df98a32bf9aa2115',1,'NumberTrie']]],
  ['reverselistnode_60',['reverseListNode',['../structNumberTrie.html#a01b73d82e9ae451d02bbbf0b4c882b47',1,'NumberTrie']]],
  ['reversenumbers_61',['reverseNumbers',['../phone__forward_8c.html#a97235c90339ae02b20c7b4b8851dbd9f',1,'phone_forward.c']]],
  ['reversetree_62',['reverseTree',['../structNumberTrie.html#ac1e141cfc08c9995480888c9f7f3e277',1,'NumberTrie']]]
];
