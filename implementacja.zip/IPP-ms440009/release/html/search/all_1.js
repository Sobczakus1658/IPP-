var searchData=
[
  ['bigger_5',['bigger',['../utils_8h.html#aeceaab334916f689c36462ddafef19e6',1,'utils.c']]]
];
