var searchData=
[
  ['removeduplicates_116',['removeDuplicates',['../utils_8h.html#aa2f3dd152ff0bde4f8ce75dd4d3369e9',1,'utils.c']]],
  ['removefromlist_117',['removeFromList',['../phone__forward_8c.html#a5487ba07291365bb9d4cff6ceb0f8e6d',1,'phone_forward.c']]],
  ['reversenumbers_118',['reverseNumbers',['../phone__forward_8c.html#a97235c90339ae02b20c7b4b8851dbd9f',1,'phone_forward.c']]]
];
