var searchData=
[
  ['parent_38',['parent',['../structNumberTrie.html#a5ecfdf14ddb9fead8dce29a9c4c9a1aa',1,'NumberTrie']]],
  ['phfwdadd_39',['phfwdAdd',['../phone__forward_8c.html#abb8f93a16db33469caccd80e87c9beff',1,'phfwdAdd(PhoneForward *pf, char const *num1, char const *num2):&#160;phone_forward.c'],['../phone__forward_8h.html#abb8f93a16db33469caccd80e87c9beff',1,'phfwdAdd(PhoneForward *pf, char const *num1, char const *num2):&#160;phone_forward.c']]],
  ['phfwddelete_40',['phfwdDelete',['../phone__forward_8c.html#a725a0fc198b7e1baec7649057ee3a3db',1,'phfwdDelete(PhoneForward *pf):&#160;phone_forward.c'],['../phone__forward_8h.html#a725a0fc198b7e1baec7649057ee3a3db',1,'phfwdDelete(PhoneForward *pf):&#160;phone_forward.c']]],
  ['phfwdget_41',['phfwdGet',['../phone__forward_8h.html#a550d535095014e99c0e2553845b74c6a',1,'phfwdGet(PhoneForward const *pf, char const *num):&#160;phone_forward.c'],['../phone__forward_8c.html#a550d535095014e99c0e2553845b74c6a',1,'phfwdGet(PhoneForward const *pf, char const *num):&#160;phone_forward.c']]],
  ['phfwdgetreverse_42',['phfwdGetReverse',['../phone__forward_8h.html#a0ef4c32d7ea8141b510777b16a0f0fda',1,'phfwdGetReverse(PhoneForward const *pf, char const *num):&#160;phone_forward.c'],['../phone__forward_8c.html#a0ef4c32d7ea8141b510777b16a0f0fda',1,'phfwdGetReverse(PhoneForward const *pf, char const *num):&#160;phone_forward.c']]],
  ['phfwdnew_43',['phfwdNew',['../phone__forward_8h.html#aaa2e5157c55a6eb50a712861d8aa8a0f',1,'phfwdNew(void):&#160;phone_forward.c'],['../phone__forward_8c.html#aaa2e5157c55a6eb50a712861d8aa8a0f',1,'phfwdNew(void):&#160;phone_forward.c']]],
  ['phfwdremove_44',['phfwdRemove',['../phone__forward_8c.html#a6234dc81f9ea0652f9740d2d9bea4522',1,'phfwdRemove(PhoneForward *pf, char const *num):&#160;phone_forward.c'],['../phone__forward_8h.html#a6234dc81f9ea0652f9740d2d9bea4522',1,'phfwdRemove(PhoneForward *pf, char const *num):&#160;phone_forward.c']]],
  ['phfwdreverse_45',['phfwdReverse',['../phone__forward_8c.html#aea6a9868097ec95f9d7fea5e935a9c2e',1,'phfwdReverse(PhoneForward const *pf, char const *num):&#160;phone_forward.c'],['../phone__forward_8h.html#aea6a9868097ec95f9d7fea5e935a9c2e',1,'phfwdReverse(PhoneForward const *pf, char const *num):&#160;phone_forward.c']]],
  ['phnumdelete_46',['phnumDelete',['../phone__forward_8c.html#a7fe73f81912cbf3cac133406626eae94',1,'phnumDelete(PhoneNumbers *pnum):&#160;phone_forward.c'],['../phone__forward_8h.html#a7fe73f81912cbf3cac133406626eae94',1,'phnumDelete(PhoneNumbers *pnum):&#160;phone_forward.c']]],
  ['phnumget_47',['phnumGet',['../phone__forward_8c.html#a74d0bf8118567e44a72d930f8354e28d',1,'phnumGet(PhoneNumbers const *pnum, size_t idx):&#160;phone_forward.c'],['../phone__forward_8h.html#a74d0bf8118567e44a72d930f8354e28d',1,'phnumGet(PhoneNumbers const *pnum, size_t idx):&#160;phone_forward.c']]],
  ['phnumnew_48',['phnumNew',['../phone__forward_8c.html#a81af7d99838e17ad7ffa875adabdada5',1,'phnumNew(void):&#160;phone_forward.c'],['../phone__forward_8h.html#a81af7d99838e17ad7ffa875adabdada5',1,'phnumNew(void):&#160;phone_forward.c']]],
  ['phone_5fforward_2ec_49',['phone_forward.c',['../phone__forward_8c.html',1,'']]],
  ['phone_5fforward_2eh_50',['phone_forward.h',['../phone__forward_8h.html',1,'']]],
  ['phoneforward_51',['PhoneForward',['../phone__forward_8h.html#aafb7fe417dedef07ddae60c548df5542',1,'PhoneForward():&#160;phone_forward.h'],['../structPhoneForward.html',1,'PhoneForward']]],
  ['phonenumber_52',['phoneNumber',['../structPhoneNumbers.html#a38f09df37733e456bbe6be038447530e',1,'PhoneNumbers']]],
  ['phonenumbers_53',['PhoneNumbers',['../phone__forward_8h.html#af03fd91aa576ca5c4764601730faa17f',1,'PhoneNumbers():&#160;phone_forward.h'],['../structPhoneNumbers.html',1,'PhoneNumbers']]],
  ['pointercharnew_54',['pointerCharNew',['../utils_8h.html#a08378b219d4e95b014ac012a79e1c2ec',1,'utils.c']]],
  ['prefiks_55',['prefiks',['../structNumberTrie.html#a6431fdfa25e7b3c910129b819318a975',1,'NumberTrie']]]
];
