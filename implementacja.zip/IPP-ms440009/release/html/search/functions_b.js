var searchData=
[
  ['trienew_122',['trieNew',['../trie_8h.html#ad44fa7bb3d9415d7015c3f67afb618e9',1,'trie.c']]]
];
