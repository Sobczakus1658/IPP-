var searchData=
[
  ['setforward_63',['setForward',['../phone__forward_8c.html#ae29132e77b5399d1f7e43e6db60a515a',1,'phone_forward.c']]],
  ['setforwardlist_64',['setForwardList',['../phone__forward_8c.html#ad048a1f5022f95f81eb8b7aa1e4488f7',1,'phone_forward.c']]],
  ['sort_65',['sort',['../phone__forward_8c.html#a0efd48244cabe6bc629d387c3867a166',1,'phone_forward.c']]]
];
