var indexSectionsWithContent =
{
  0: "abcdfilmnprstu",
  1: "lnp",
  2: "lptu",
  3: "abcdfilmprst",
  4: "acfmnpr",
  5: "lnp",
  6: "m",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Struktury Danych",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne",
  5: "Definicje typów",
  6: "Definicje",
  7: "Strony"
};

