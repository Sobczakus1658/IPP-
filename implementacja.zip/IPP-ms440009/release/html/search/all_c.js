var searchData=
[
  ['trie_2eh_66',['trie.h',['../trie_8h.html',1,'']]],
  ['trienew_67',['trieNew',['../trie_8h.html#ad44fa7bb3d9415d7015c3f67afb618e9',1,'trie.c']]]
];
