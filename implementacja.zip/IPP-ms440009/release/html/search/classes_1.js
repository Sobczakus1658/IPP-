var searchData=
[
  ['numbertrie_70',['NumberTrie',['../structNumberTrie.html',1,'']]]
];
