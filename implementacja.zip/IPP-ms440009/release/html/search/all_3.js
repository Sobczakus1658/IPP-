var searchData=
[
  ['datavalidation_15',['dataValidation',['../trie_8h.html#a66ca46e0a1a31838d15c8cc672ae57a7',1,'trie.c']]],
  ['delete_16',['delete',['../phone__forward_8c.html#a1c8c9d3add0f4f2a7c5464d49569b416',1,'phone_forward.c']]],
  ['deleteforwardfromreverse_17',['deleteForwardFromReverse',['../phone__forward_8c.html#a254aba9550f41435fbd672e3ca935ce6',1,'phone_forward.c']]],
  ['deletelist_18',['deleteList',['../list_8c.html#a084ddc3918820afdcbfb85bb8d7d0788',1,'deleteList(ListNode *list):&#160;list.c'],['../list_8h.html#a084ddc3918820afdcbfb85bb8d7d0788',1,'deleteList(ListNode *list):&#160;list.c']]],
  ['deletetrie_19',['deleteTrie',['../trie_8h.html#a018b0ea750d920d1595e65861daecca8',1,'trie.c']]],
  ['dokumentacja_20zadania_20telefony_20',['Dokumentacja zadania telefony',['../index.html',1,'']]]
];
