var searchData=
[
  ['reverse_132',['reverse',['../structPhoneForward.html#a39d6c991760bef09ea7eea329515ff6b',1,'PhoneForward']]],
  ['reverselist_133',['reverseList',['../structNumberTrie.html#a3138af2bfb114275df98a32bf9aa2115',1,'NumberTrie']]],
  ['reverselistnode_134',['reverseListNode',['../structNumberTrie.html#a01b73d82e9ae451d02bbbf0b4c882b47',1,'NumberTrie']]],
  ['reversetree_135',['reverseTree',['../structNumberTrie.html#ac1e141cfc08c9995480888c9f7f3e277',1,'NumberTrie']]]
];
