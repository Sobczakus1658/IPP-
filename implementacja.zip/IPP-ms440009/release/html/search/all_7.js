var searchData=
[
  ['max_5fchildren_32',['MAX_CHILDREN',['../phone__forward_8h.html#ac760eaf4b19dd6359a2b1e52091ae919',1,'phone_forward.h']]],
  ['memoryallocatedsize_33',['memoryAllocatedSize',['../structPhoneNumbers.html#a5e0e6a6a56f94ed6e254349c4e3105ce',1,'PhoneNumbers']]],
  ['minn_34',['minn',['../utils_8h.html#a16099fec53eff6266d2b3c638cd043ad',1,'utils.c']]]
];
